class CreatePosts < ActiveRecord::Migration
  def change
    create_table(:posts) { |t|
      t.text :text, null: false
      t.timestamps null: false

      t.belongs_to :user, index: true
      t.belongs_to :topic, index: true
    }
  end
end
