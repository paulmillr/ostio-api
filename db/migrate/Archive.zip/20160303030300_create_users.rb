class CreateUsers < ActiveRecord::Migration
  def change
    create_table(:users) { |t|
      t.string :login, index: true
      t.string :github_token, index: true

      t.string :type
      t.string :name, default: ''
      t.string :email, default: ''
      t.string :avatar_url

      t.boolean :enabled_email_notifications, default: false
      t.timestamps null: false
    }

    create_table(:organization_owners, id: false) { |t|
      t.belongs_to :owner, index: true
      t.belongs_to :organization, index: true
    }

    add_reference :users, :repos
    add_reference :users, :topics
    add_reference :users, :posts
  end
end
