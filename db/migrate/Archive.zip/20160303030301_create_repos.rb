class CreateRepos < ActiveRecord::Migration
  def change
    create_table(:repos) { |t|
      t.string :name
      t.timestamps null: false
      t.belongs_to :user, index: true
    }

    add_reference :repos, :topics
  end
end
